# train_model.py

import pandas as pd
import numpy as np
import joblib
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.impute import SimpleImputer
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import GradientBoostingClassifier

# ---------------------------------------------------
# 1. Load the Dataset
# ---------------------------------------------------
try:
    df = pd.read_csv('files/Final_Preprocess1_winsorize.csv', encoding='ISO-8859-1')
    print("Dataset loaded successfully.")
except FileNotFoundError:
    print("Error: The specified CSV file was not found.")
    exit(1)
except Exception as e:
    print(f"An error occurred while loading the dataset: {e}")
    exit(1)

# ---------------------------------------------------
# 2. Define Features and Target Variable
# ---------------------------------------------------
# List of features to extract
feature_columns = [
    'Name', 'Sector', 'Sub-Sector', 'Market Cap', 'Return on Equity', 'ROCE',
    'Cash Flow Margin', 'EBITDA Margin', 'Net Profit Margin', 'Return on Assets',
    'Asset Turnover Ratio', 'Working Capital Turnover Ratio', 'Current Ratio',
    'Debt to Equity', 'PE Ratio', 'PB Ratio', 'Sector PE', 'Sector PB', 'PS Ratio',
    'Sector Dividend Yield', 'Return on Investment', 'MF Holding Change 3M',
    'MF Holding Change 6M', 'FII Holding Change 3M', 'FII Holding Change 6M',
    'DII Holding Change 3M', 'DII Holding Change 6M', 'EPS (Q)', 'Dividend Per Share',
    'Debt to Asset', 'R2'
]

# Extract the specified features
features = df[feature_columns].copy()

# Convert all columns except 'Name', 'Sector', and 'Sub-Sector' to numeric
non_categorical_cols = ['Name', 'Sector', 'Sub-Sector']
for col in features.columns:
    if col not in non_categorical_cols:
        features[col] = pd.to_numeric(features[col], errors='coerce')

# Drop rows with missing target variable 'R2'
features.dropna(subset=['R2'], inplace=True)

# Define target variable and features
X = features.drop(columns=['Name', 'R2', 'Sub-Sector'])
y = features['R2']

# ---------------------------------------------------
# 3. Identify Numerical and Categorical Features
# ---------------------------------------------------
categorical_features = ['Sector']
numerical_features = X.columns.difference(categorical_features)

# ---------------------------------------------------
# 4. Define Preprocessing Pipelines
# ---------------------------------------------------
# Pipeline for numerical features
numeric_transformer = Pipeline(steps=[
    ('imputer', SimpleImputer(strategy='mean')),       # Handle missing values
    ('scaler', StandardScaler())                       # Feature scaling
])

# Pipeline for categorical features
categorical_transformer = Pipeline(steps=[
    ('imputer', SimpleImputer(strategy='most_frequent')),  # Handle missing values
    ('onehot', OneHotEncoder(handle_unknown='ignore', sparse_output=False))  # One-hot encoding
])

# Combine numerical and categorical transformers
preprocessor = ColumnTransformer(
    transformers=[
        ('num', numeric_transformer, numerical_features),
        ('cat', categorical_transformer, categorical_features)
    ]
)

# ---------------------------------------------------
# 5. Define the Classifier
# ---------------------------------------------------
classifier = GradientBoostingClassifier(
    n_estimators=200,
    learning_rate=0.1127050307613042,
    max_depth=4,
    random_state=42
)

# ---------------------------------------------------
# 6. Create the Pipeline
# ---------------------------------------------------
model = Pipeline(steps=[
    ('preprocessor', preprocessor),
    ('classifier', classifier)
])

# ---------------------------------------------------
# 7. Train the Model
# ---------------------------------------------------
print("Starting model training...")
model.fit(X, y)
print("Model training completed.")

# ---------------------------------------------------
# 8. Save the Trained Model
# ---------------------------------------------------
model_filename = 'model.pkl'
joblib.dump(model, model_filename)
print(f"Model saved to {model_filename}")

# ---------------------------------------------------
# 9. Save Unique Sectors
# ---------------------------------------------------
unique_sectors = X['Sector'].unique()
sectors_filename = 'unique_sectors.pkl'
joblib.dump(unique_sectors, sectors_filename)
print(f"Unique sectors saved to {sectors_filename}")
