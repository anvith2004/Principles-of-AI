# app.py
from flask import Flask, request, render_template
import joblib
import numpy as np
import pandas as pd

app = Flask(__name__)

# Load the model and unique sectors
model = joblib.load('model.pkl')
unique_sectors = joblib.load('unique_sectors.pkl')

# Define the list of features needed for prediction
feature_names = [
    'Sector', 'Market Cap', 'Return on Equity', 'ROCE',
    'Cash Flow Margin', 'EBITDA Margin', 'Net Profit Margin', 'Return on Assets',
    'Asset Turnover Ratio', 'Working Capital Turnover Ratio', 'Current Ratio',
    'Debt to Equity', 'PE Ratio', 'PB Ratio', 'Sector PE', 'Sector PB', 'PS Ratio',
    'Sector Dividend Yield', 'Return on Investment', 'MF Holding Change 3M',
    'MF Holding Change 6M', 'FII Holding Change 3M', 'FII Holding Change 6M',
    'DII Holding Change 3M', 'DII Holding Change 6M', 'EPS (Q)', 'Dividend Per Share',
    'Debt to Asset'
]

# Mapping for R2 labels
r2_labels = {0: 'Not Recommended', 1: 'Mildly Recommended', 2: 'Highly Recommended'}

@app.route('/')
def home():
    return render_template('index.html', feature_names=feature_names, sectors=unique_sectors)

@app.route('/predict', methods=['POST'])
def predict():
    # Get form data
    data = request.form
    # Prepare the input data in the correct order
    input_data = []
    for feature in feature_names:
        value = data.get(feature)
        # Convert to appropriate type
        if feature == 'Sector':
            input_data.append(value)
        else:
            try:
                input_data.append(float(value))
            except:
                input_data.append(np.nan)
    # Create a DataFrame
    X_input = pd.DataFrame([input_data], columns=feature_names)
    # Make prediction
    prediction = model.predict(X_input)[0]
    prediction_label = r2_labels.get(prediction, 'Unknown')
    return render_template('result.html', prediction=prediction_label)

if __name__ == "__main__":
    app.run(debug=True)
